@extends('admin.index')
@section('content')
    <div class="jumbotron">
        <h1>Welcome to My Lavarel App</h1>
    </div>
@endsection
